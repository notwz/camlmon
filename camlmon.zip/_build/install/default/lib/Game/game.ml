(** @canonical Game.Battle *)
module Battle = Game__Battle


(** @canonical Game.Battle_encounter *)
module Battle_encounter = Game__Battle_encounter


(** @canonical Game.Encounter *)
module Encounter = Game__Encounter


(** @canonical Game.Gui_library *)
module Gui_library = Game__Gui_library


(** @canonical Game.Main_menu *)
module Main_menu = Game__Main_menu


(** @canonical Game.Safari_zone *)
module Safari_zone = Game__Safari_zone
