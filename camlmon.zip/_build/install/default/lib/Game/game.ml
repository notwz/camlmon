(** @canonical Game.Encounter *)
module Encounter = Game__Encounter


(** @canonical Game.Explore *)
module Explore = Game__Explore


(** @canonical Game.Gui *)
module Gui = Game__Gui


(** @canonical Game.Gui_library *)
module Gui_library = Game__Gui_library


(** @canonical Game.Main_menu *)
module Main_menu = Game__Main_menu


(** @canonical Game.Safari_zone *)
module Safari_zone = Game__Safari_zone
