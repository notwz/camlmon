(** @canonical Lib.Author *)
module Author = Lib__Author


(** @canonical Lib.Catch_state *)
module Catch_state = Lib__Catch_state


(** @canonical Lib.Map *)
module Map = Lib__Map


(** @canonical Lib.Map_command *)
module Map_command = Lib__Map_command


(** @canonical Lib.Math *)
module Math = Lib__Math


(** @canonical Lib.P_state *)
module P_state = Lib__P_state


(** @canonical Lib.Pokemon *)
module Pokemon = Lib__Pokemon


(** @canonical Lib.T_state *)
module T_state = Lib__T_state


(** @canonical Lib.Trainer *)
module Trainer = Lib__Trainer
