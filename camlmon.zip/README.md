# camlmon
A pokemon-esque game built using OCaml for Cornell University's SP22 3110 course. 

# Contributors 

- Will Zhang
- Yunci Sun
- Maxwell Pang


# MS0 
- [ ] Basic terminal main menu UI. 
- [ ] User Login 
- [ ] Load pokemon catching map 
