(** @canonical Pokedex.Kanto *)
module Kanto = Pokedex__Kanto
